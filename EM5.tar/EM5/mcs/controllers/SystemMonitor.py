# This module was conceptualized but never implemented. The
#   idea was to periodically spit it out system data for 
#   monitoring/debugging. The output would depend on one of
#   three state. System start up would verify all modules are
#   online and ready. For example, GPS RTK and LiDar should be
#   active before the program starts doing anything. During regular
#   runtime it would display besic data such as FSM state, battery
#   health, GPS, etc.. Finally, when the programs is shutting down
#   it would display which modules are still active (occasionally
#   one module won't shutdown properly and we're not sure which).

System Startup

+------------------------------+
| Statup Monitor: Ready        |
+------------------------------+
| Route Planning: Ready 
| GNSS: Ready
| GNSS RTK: Disabled
| LiDar: Ready
| Remote Control: Waiting
| Active Collision: False
| Object Detected: False
| Battery: 50%
+------------------------------+

+------------------------------+
| System Monitor               |
+------------------------------+
| State 1: shutdown
| State 2: 
| GPS Longitude: 
| GPS Latitude: 
| RTK Status: 
| GPS Heading:
| Destination Heading: 
| 
|
+------------------------------+

+------------------------------+
| Shutdown Monitor             |
+------------------------------+
| State 1: shutdown
| State 2: 
| GPS Longitude: 
| GPS Latitude: 
| RTK Status: 
| GPS Heading:
| Destination Heading: 
| 
|
+------------------------------+


