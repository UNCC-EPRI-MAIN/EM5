# standard libraries
import time
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM) 
import importlib
import threading

# module parameters
PIVOT_SPEED = 50
DISTANCE_WHEEL_TO_WHEEL = 93 # distance in cm measured from center of wheel to other
PIVOT_CIRCUMFERENCE = 3.14 * DISTANCE_WHEEL_TO_WHEEL # 292.02 cm
DISTANCE_PER_DEGREE = PIVOT_CIRCUMFERENCE / 360 # 0.811 cm for each degree
NORMAL_DRIVE_SPEED = 50
COURSE_CORRECTION_FACTOR = 0.5 # higher number -> faster correction
#success at 0.3 , 0.4 better?

# mcs modules
import mcs.pinAssignments as pins
import mcs.testFlags as tFlags

# relay control module
if tFlags.RelayControl_over:
    testDir = "test.routines.test" + str(tFlags.testNum) + ".RelayControl"
    relay_control = importlib.import_module(testDir)
else:
    import mcs.firmware.RelayControl as RelayControl
# sabertooth module
if tFlags.Sabertooth2x60_over:
    testDir = "test.routines.test" + str(tFlags.testNum) + ".Sabertooth2x60"
    Sabertooth2x60 = importlib.import_module(testDir)
else:
    import mcs.firmware.Sabertooth2x60 as Sabertooth2x60

# encoders module
if tFlags.AMT103_over:
    testDir = "test.routines.test" + str(tFlags.testNum) + ".AMT103"
    AMT103 = importlib.import_module(testDir)
else:
    import mcs.firmware.AMT103 as AMT103

class DriveControl:

    def __init__(self):
        # set debugging info
        ## Boolean indicating if debug info should be included for this module
        self.debug = tFlags.DriveControl_debug
        ## Boolean to indicate if this motor should be used. If disabled, program will run but not attempt to operate motors.
        self.enabled = tFlags.DriveControl_enabled
        ## String used for debugging
        self.debugPrefix = "[DriveControl]"
        self.leftSpeed = 0
        self.rightSpeed = 0
        if tFlags.DriveControl_over:
            self.debugPrefix += "[O]"
        if self.enabled:
            self.debugPrefix += "[E]"
        else:
            self.debugPrefix += "[D]"  
        if self.debug:
            print(self.debugPrefix + "[__init__()]: defining DriveControl")
        if self.enabled:
            self.relay = RelayControl.RelayControl(pins.wheelRelay, tFlags.wheelRelay_debug, tFlags.wheelRelay_enabled, tFlags.RelayControl_over, "Wheel")
            self.leftMotor = Sabertooth2x60.Sabertooth2x60(pins.leftMotorPWM, tFlags.leftMotor_debug, tFlags.leftMotor_enabled, tFlags.Sabertooth2x60_over, "Left")
            self.rightMotor = Sabertooth2x60.Sabertooth2x60(pins.rightMotorPWM, tFlags.rightMotor_debug, tFlags.rightMotor_enabled, tFlags.Sabertooth2x60_over, "Right")
            #self.leftEncoder = AMT103.AMT103(pins.leftEncoderX, pins.leftEncoderA, tFlags.leftEncoder_debug, tFlags.leftEncoder_enabled, tFlags.AMT103_over, "Left")
            self.rightEncoder = AMT103.AMT103(pins.rightEncoderX, pins.rightEncoderA, tFlags.rightEncoder_debug, tFlags.rightEncoder_enabled, tFlags.AMT103_over, "Right")

    # drive striaght based at given speed
    def straight(self, speed):
        self.leftSpeed = speed
        self.rightSpeed = speed
        if self.debug:
            print(self.debugPrefix + "[stright()]: driving straight")
        if self.enabled:
            self.leftMotor.engage(speed)
            self.rightMotor.engage(speed + 5)

    # drive straight a certain distance
    def straightDistance(self, distance_m):
        distance_cm = distance_m * 100 
        if self.debug:
            print(self.debugPrefix + "[straightDistance()]: distance (cm) = " + str(distance_cm))
        if self.enabled:
            thread_rightEncoder = threading.Thread(target = self.rightEncoder.countDown, args = (distance_cm, ))
            thread_rightEncoder.start()
            self.leftMotor.engage(NORMAL_DRIVE_SPEED)
            self.rightMotor.engage(NORMAL_DRIVE_SPEED + 4)
            thread_rightEncoder.join()
            self.leftMotor.stop()
            self.rightMotor.stop()
            if self.debug:
                print(self.debugPrefix + "[straightDistance()]: pivot complete")

    # steer to the right
    # Degrees is the number of degrees off course, higher degrees means
    #   faster correction speeds
    def veerRightDegrees(self, degrees):
        # calculate correction speed
        correctionSpeed = int(COURSE_CORRECTION_FACTOR * degrees)
        # fix correction speed if exceeds max
        if correctionSpeed > 20:
            correctionSpeed = 20
        self.leftSpeed = correctionSpeed + NORMAL_DRIVE_SPEED
        self.rightSpeed = NORMAL_DRIVE_SPEED
        if self.debug:
            print(self.debugPrefix + "[veerRight()]: ")
        if self.enabled:
            self.leftMotor.engage(self.leftSpeed)
            self.rightMotor.engage(self.rightSpeed)

    # steer to the left
    # Degrees is the number of degrees off course, higher degrees means
    #   faster correction speeds
    def veerLeftDegrees(self, degrees):
        self.leftSpeed = NORMAL_DRIVE_SPEED
        # calculate correction speed
        correctionSpeed = int(COURSE_CORRECTION_FACTOR * degrees)
        # fix correction speed if exceeds max
        if correctionSpeed > 20:
            correctionSpeed = 20
        self.rightSpeed = correctionSpeed + NORMAL_DRIVE_SPEED
        #self.rightSpeed = NORMAL_DRIVE_SPEED + 10
        if self.debug:
            print(self.debugPrefix + "[veerLeft()]: ")
        if self.enabled:
            self.leftMotor.engage(self.leftSpeed)
            self.rightMotor.engage(self.rightSpeed)

    # pivot to the right
    def pivotRight(self, degrees):
        degrees = degrees * 1.11
        distance  = int(degrees * DISTANCE_PER_DEGREE)
        if self.debug:
            print(self.debugPrefix + "[pivotRight()]: degrees = " + str(degrees))
            print(self.debugPrefix + "[pivotRight()]: distance (cm) to travel = " + str(distance))
        if self.enabled:
            thread_rightEncoder = threading.Thread(target = self.rightEncoder.countDown, args = (distance, ))
            thread_rightEncoder.start()
            self.leftMotor.engage(PIVOT_SPEED-9)
            self.rightMotor.engage(-PIVOT_SPEED)
            thread_rightEncoder.join()
            #time.sleep(4.5) # for time based 180
            self.leftMotor.stop()
            self.rightMotor.stop()
            if self.debug:
                print(self.debugPrefix + "[pivotRight()]: pivot complete")

    ## Stops motor by setting PWM to 50.
    def pivotLeft(self, degrees):
        distance  = int(degrees * DISTANCE_PER_DEGREE)
        if self.debug:
            print(self.debugPrefix + "[pivotLeft()]: degrees = " + str(degrees))
            print(self.debugPrefix + "[pivotLeft()]: distance (cm) to travel = " + str(distance))
        if self.enabled:
            thread_rightEncoder = threading.Thread(target = self.rightEncoder.countDown, args = (distance, ))
            thread_rightEncoder.start()
            self.leftMotor.engage(-PIVOT_SPEED)
            self.rightMotor.engage(PIVOT_SPEED)
            thread_rightEncoder.join()
            self.leftMotor.stop()
            self.rightMotor.stop()
            if self.debug:
                print(self.debugPrefix + "[pivotLeft()]: pivot complete")


    # explicitly set left wheel speed
    def manualSetLeftSpeed(self, speed):
        self.leftSpeed = speed
        if self.enabled:
                self.leftMotor.engage(speed)
            
    # explicity set left and right wheel speeds
    def setManualSpeed(self, newLeftSpeed, newRightSpeed):
        self.leftSpeed = newLeftSpeed
        self.rightSpeed = newRightSpeed
        if self.enabled:
            self.leftMotor.engage(newLeftSpeed)
            self.rightMotor.engage(newRightSpeed)

    # explicitly set right wheel speed.
    def manualSetRightSpeed(self, speed):
        self.rightSpeed = speed
        if self.enabled:
            self.rightMotor.engage(speed)
    
    # enable wheel motors by closing relay
    def enable(self):
        if self.debug:
            print(self.debugPrefix + "[enable()]: driving straight")
        if self.enabled:
            self.relay.enable()
    
    # disable wheel motors by opening relay
    def disable(self):
        self.leftSpeed = 0
        self.rightSpeed = 0
        if self.debug:
            print(self.debugPrefix + "[disable()]: driving straight")
        if self.enabled:
            self.relay.disable()

    # rapidly stop robot by setting speed to 0
    # will also disable motors
    def rapidStop(self):
        self.leftSpeed = 0
        self.rightSpeed = 0
        if self.debug:
            print(self.debugPrefix + "[rapidStop()]: turning on motors")
        if self.enabled:
            self.leftMotor.stop()
            self.rightMotor.stop()
            self.relay.disable()

    # gracefully stop robot by slowing down
    def stop(self):
        if self.debug:
            print(self.debugPrefix + "[stop()]: turning on motors")
        if self.enabled:
            self.leftSpeed = self.rightSpeed
            while self.leftSpeed > 0:
                self.leftSpeed -= 1
                self.leftMotor.engage(self.leftSpeed)
                self.rightMotor.engage(self.rightSpeed)
                time.sleep(0.01)
            self.speed = 0
            self.leftMotor.engage(self.speed)
            self.rightMotor.engage(self.speed)