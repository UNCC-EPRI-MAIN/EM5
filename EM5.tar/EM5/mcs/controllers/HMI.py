# HMI
#
# This module is a placeholder for a future HMI (touchscreen 
#   interface). Right now its only function is to get test 
#   number from terminal where program was run.

def getTestNum():
    testNum = input("Enter test number: ")
    testNum = int(testNum)
    return testNum