# standard libraries
import importlib
import threading
import multiprocessing as multiproc
from dataclasses import dataclass
import math
import time
from geopy.distance import great_circle

# mcs modules
import mcs.pinAssignments as pins

# parameters
ratio = 85 / 100 # ratio of lat to lon
DISTANCE_THRESHOLD = 4 # distance (M) to qualify as reached destination
    # this value has been successfully set at 1.5 in some runs

# special object type for gps coordinates
# It may be desirable to add a third element as a string to use for special
#   flags that could indicate a pviot should be carried out when reaching point
@dataclass
class waypoint:
    lon: float
    lat: float

# helper function to claculate the destination heading from current GPS location 
#   and destination GPS point. Recall compass degrees != regualar graph degrees
def getDestinationHeading(currentLon, currentLat, destinationLon, destinationLat):
    # get heading in radians
    heading = math.atan2(destinationLat - currentLat, ratio * (destinationLon - currentLon))
    # convert to degreees and adjust for compass orienation
    heading = 90 - math.degrees(heading)
    # fix if less than zero
    if heading < 0:
        heading += 360
    return heading

# helper function to determine if destination has been reached. Calculates the distance
#   betweeen the current GPS point and the destination. if the threshold is below a
#   certain amount the destiantion is said to be reached.
def arrivedAtDestination(currentLon, currentLat, destinationLon, destinationLat):
    p1 = (currentLat, currentLon)
    p2 = (destinationLat, destinationLon)
    distance = great_circle(p1, p2).meters
    if distance < DISTANCE_THRESHOLD:
        return True
    else:
        return False

# main function
def run(globals):

    # load test flags
    testNum = globals['testNum']
    if testNum > 0:
        testFile = "test.routines.test" + str(testNum) + ".testFlags"
        tFlags = importlib.import_module(testFile)
    else:
        import mcs.testFlags as tFlags

    # set debugging data
    ## Boolean indicating if debug info should be included for this module
    debug = tFlags.Navigation_debug
    ## Boolean to indicate if blade motors should be used. 
    enabled = tFlags.Navigation_enabled
    ## String used for debugging
    debugPrefix = "[Navigation]"
    if enabled:
        debugPrefix += "[E]: "
    else:
        debugPrefix += "[D]: "  
    if debug:
        print(debugPrefix + "init blade controller")

    if enabled:
        # load GPS module
        if tFlags.NEO_M8P_over:
            testDir = "test.routines.test" + str(testNum) + ".NEO_M8P"
            NEO_M8P = importlib.import_module(testDir)
        else:
            import mcs.firmware.NEO_M8P as NEO_M8P
        # start GPS thread
        thread_gps = threading.Thread(target = NEO_M8P.run, args = (tFlags.NEO_M8P_debug, tFlags.NEO_M8P_enabled, tFlags.NEO_M8P_RTK_enabled, tFlags.NEO_M8P_over, pins.rtkStatus, globals))
        thread_gps.start()

    if enabled:
        
        # go to waypoint A
        #A = waypoint(-80.633826599, 34.929116199)
        A = waypoint(0,0)
        destinationLon = A.lon
        destinationLat = A.lat
        # these values were temporarily disabled for testing
        newDestinationHeading = -1
        prevDestinationHeading = -1

        # main loop
        while globals['state1'] != 'shutdown':
            time.sleep(1)
            startx = globals['startLon']
            starty = globals['startLat']
            #print("start x and y = " + str(x) + " " + str(y))
            currentLon = globals['lon']
            currentLat = globals['lat']
            # make sure gps readings are good
            if currentLon != -1 and currentLat != -1:
                # get destination heading from current and destination position
                newDestinationHeading = getDestinationHeading(currentLon, currentLat, destinationLon, destinationLat)
                # update globals if new value
                if newDestinationHeading != prevDestinationHeading:
                    globals['destinationHeading'] = newDestinationHeading
                #if debug:
                #    print(debugPrefix + ": destination heading = " + str(newDestinationHeading))
                # arrived at destination
                #if False:
                if arrivedAtDestination(currentLon, currentLat, destinationLon, destinationLat):
                    print(debugPrefix + ": destination reached")
                    if globals['state1'] == 'returnToStart':
                        print("Arrived at start position")
                        globals['state1'] = 'shutdown'
                        break
                    else:
                        print("Arrived at first point")
                        globals['state1'] = 'returnToStart'
                        globals['state2'] = 'init'
                        destinationLat = globals['startLat']
                        destinationLon = globals['startLon']
                    globals['atDestination'] = True
    # wait for threads to end
    if enabled:
        thread_gps.join()

    print(debugPrefix + "end of module")