## @package mcs.InterruptControl
# Handles LiDar, Bumpers, and Battery Monitor (future)
#
# This module oversees several modules that may interrupt
#   the main program. This module runs in its own process
#   spawned by MowBotControl and spawns seperate threads
#   for the LiDar and Collision Detection modules. The LiDar
#   is used for object detection and the Collision Detection
#   detects a collision when bumpers are pressed. These modules
#   communicate to other modules using the shared dictionary
#   "globals"
# @author Keith
# @note 03/19/2021: Updated documentation -KS

# standard libraries
import os
import importlib
import threading
import time

# main function
def run(globals):
  
    # load test flags
    testNum = globals['testNum']
    if testNum > 0:
        testFile = "test.routines.test" + str(testNum) + ".testFlags"
        tFlags = importlib.import_module(testFile)
    else:
        import mcs.testFlags as tFlags

    # create debug info
    debug = tFlags.InterruptControl_debug
    enabled = tFlags.InterruptControl_enabled
    debugPrefix = "[InterruptCont]"
    if tFlags.InterruptControl_over:
        debugPrefix += "[O]"
    if enabled:
        debugPrefix += "[E]"
    else:
        debugPrefix += "[D]"  
    if debug:
        print(debugPrefix + ": process spawned")
        print(debugPrefix + ": process id = " + str(os.getpid()))

    # load collision detection controller
    if tFlags.CollisionDetection_over:
        testDir = "test.routines.test" + str(testNum) + ".CollisionDetection"
        CollisionDetection = importlib.import_module(testDir)
    else:
        import mcs.controllers.CollisionDetection as CollisionDetection
    # start collision detection thread
    if enabled:
        thread_collisionDetection = threading.Thread(target = CollisionDetection.run, args = (globals, ))
        thread_collisionDetection.start()

    # load object dection
    if tFlags.rpLiDAR_A2M4_R4_over:
        testDir = "test.routines.test" + str(testNum) + ".rpLiDAR_A2M4_R4"
        rpLiDAR_A2M4_R4 = importlib.import_module(testDir)
    else:
        import mcs.firmware.rpLiDAR_A2M4_R4 as rpLiDAR_A2M4_R4
    # start object detection thread
    if enabled:
        lidar = rpLiDAR_A2M4_R4.rpLiDAR_A2M4_R4(tFlags.rpLiDAR_A2M4_R4_debug, tFlags.rpLiDAR_A2M4_R4_enabled, tFlags.rpLiDAR_A2M4_R4_over)
        thread_objectDetection = threading.Thread(target = lidar.objectDetection, args = (globals, ))
        thread_objectDetection.start()

    # main loop, wait for shutdown
    while globals['state1'] != 'shutdown':
        time.sleep(2)

    # wait for threads to end
    if enabled:
        thread_objectDetection.join()
        thread_collisionDetection.join()

    print(debugPrefix + ": end of process")