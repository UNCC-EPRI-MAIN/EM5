# Relay Control Testbench
# 
# Hardware Requirments:
#   Pi and PCB should be powered on. Relay to be tested should
#   be wired up. If testing the blade relay, the blade switch 
#   will need to be on. If testing the wheel relay, the wheel 
#   switch needs to be on as well as the wireless cut-off relay.
#
# Test Behavior:
#   Test is for a single bumper. Once a second the state of the
#   bumeper will be displayed in the terminal. Note that the 
#   bumpers pins are normally high. Pressing a bumper will pull
#   the pin state low. Test will run forever, use CTL-C to quit.
#
# Command to Execute Test (from EM6 directory)
#   python3 -m test.firmware.Bumper_TB

# standard libraries
import time
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM) 

# module to be tested
from mcs.firmware.RelayControl import RelayControl

print("\n\n<---------- Testbench for RelayControl ---------->\n")


# create relay instance
# relay should be open by default
r1Pin = 23
r1DebugFlag = True
r1EnabledFlag = True
r1DebugName = "relay1"
r2Pin = 24
r2DebugFlag = True
r2EnabledFlag = True
r2DebugName = "relay1"
r3Pin = 25
r3DebugFlag = True
r3EnabledFlag = True
r3DebugName = "relay1"
r1 = RelayControl(r1Pin, r1DebugFlag, r1EnabledFlag, False, r1DebugName)
#r2 = RelayControl(r2Pin, r2DebugFlag, r2EnabledFlag, False, r2DebugName)
#r3 = RelayControl(r3Pin, r3DebugFlag, r3EnabledFlag, False, r3DebugName)


#test routine
time.sleep(2)
r1.enable()
time.sleep(2)
#r1.disable()
time.sleep(2)
#r2.enable()
time.sleep(2)
#r2.disable()
time.sleep(2)
#r3.enable()
time.sleep(2)
#r3.disable()
time.sleep(2)

GPIO.cleanup()
print("\n<---------- Test Complete ---------->\n\n")