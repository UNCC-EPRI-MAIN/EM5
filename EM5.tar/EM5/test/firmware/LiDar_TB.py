from rplidar import RPLidar as LD


lidar = LD('/dev/ttyUSB0')
print(lidar.get_info())
#lidar.stop()
#lidar.stop_motor()
#lidar.disconnect()
#lidar.get_health()
#print(val)
#lidar.start_motor()
# print(value)
#print(lidar.get_health())