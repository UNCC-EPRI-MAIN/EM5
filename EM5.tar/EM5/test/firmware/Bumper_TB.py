# Bumper Testbench
# 
# Hardware Requirments:
#   Bumpers should be connected to PCB
#   Pi and PCB should be powered on
#
# Test Behavior:
#   Test is for a single bumper. Once a second the state of the
#   bumeper will be displayed in the terminal. Note that the 
#   bumpers pins are normally high. Pressing a bumper will pull
#   the pin state low. Test will run forever, use CTL-C to quit.
#
# Command to Execute Test (from EM6 directory)
#   python3 -m test.firmware.Bumper_TB

# standard libraries
import time
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM) 

# module to be tested
from mcs.firmware.Bumper import Bumper

print("\n\n<---------- Testbench for Bumper ---------->\n")

# module parameters
pin = 25 # second from left
debugFlag = True
enabledFlag = True
overideFlag = False
debugName = "someBumper"

# declare bumper
bumper = Bumper(pin, debugFlag, enabledFlag, overideFlag, debugName)


# test routine
while True:

    #Monitor the state of the Bumper and display output
    state = bumper.state()
    if state:
        print("Bumper Not Pressed")
    else:
        print("Bumper Pressed")    

    time.sleep(1)  
   
GPIO.cleanup()
