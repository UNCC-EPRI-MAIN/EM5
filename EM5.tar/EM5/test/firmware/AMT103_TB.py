# Modified by Ithamar and Keith

import time
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM) 

# module to be tested
from mcs.firmware.AMT103 import AMT103

print("\n\n<---------- Testbench for Bumper ---------->\n")


# create bumper instance
# the bumper should be open by default

#encLeft = AMT103(15, 0, True, True, False, "left") #right
encLeft = AMT103(23, 0, True, True, False, "left") # left



#test routine
encLeft.countDown(104)     
   
GPIO.cleanup()
