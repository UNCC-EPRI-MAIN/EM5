## @package mcs.DriveSysControl
# Primary process for mcs. 
#
# This file is an auxillary file used to assign GPIO pin assignments for various purposes.
# This file ensures pin numbers do not conflict and provides a mechanism for quick changes.
# All pin numbers use BCM mode. See Raspberry Pi GPIO for more information.
# @author Keith
# @note 03/19/2021: Updated documentation -KS

# standard libaries
import os
import time
import importlib
import threading

# module parameters
NORMAL_DRIVE_SPEED = 50
CAUTION_DRIVE_SPEED = 40
OBJECT_DETECTION_SLOW_DOWN_FACTOR = 1.5 # lower number -> more gradual slowdown
stopDistance = 15 # cm
STOP_DISTANCE = 15 # cm
OBJECT_DETECTION_STOP_DISTANCE = 15 # was 15
OBJECT_AVOIDANCE_STOP_DISTANCE = 40 #was 27
PIVOT_SPEED = 18 # % motor speed
DEGREES_OFF_COURSE = 3 # threshold to determine MowBot is off course
DEGREES_FORCE_PIVOT = 90 # number of degrees off course requiring pivot


def slowDownSpeed(distance):
    # reached stop distance
    if distance < OBJECT_DETECTION_STOP_DISTANCE:
        speed = 0
    else:
        speed = int(OBJECT_DETECTION_SLOW_DOWN_FACTOR * (distance - OBJECT_DETECTION_STOP_DISTANCE))
    if speed > NORMAL_DRIVE_SPEED:
        speed = NORMAL_DRIVE_SPEED
    if speed < 0:
        speed = 0
    return speed

def degrOff(destination, current):
    degOff = abs(destination - current)
    if degOff <= 180:
        if destination < current:
            adjustHeading = 'left'
        else:
            adjustHeading = 'right'
    elif degOff > 180:
        if destination > current:
            larger = destination
            smaller = current
            adjustHeading = 'left'
        else:
            larger = current
            smaller = destination
            adjustHeading = 'right'
        degOff = 360 - larger + smaller
    else:
        print("failure in degrees off function")
    return degOff, adjustHeading

def run(globals):
    
    def avoidObject():
        # check for correct distance
        print("Object Avoidacne")
        #globals['destinationHeading'] = globals['heading']
        lastHeading = globals['heading']
        print("last heading: " + str(lastHeading))
        tempHeading = lastHeading + 90
        if tempHeading > 359:
            tempHeading -= 360
        globals['heading'] = tempHeading
        #if globals['forwardClearnce'] < STOP_DISTANCE:
            # reverse
            #continue
            #while globals['forwardClearance'] != 15:
            #    drive.reverse(-50)
            #drive.stop()
            #drive.turn("left")
        # carry out right pivots
        drive.pivotRight(90)
        # avoid routine
        drive.straight(CAUTION_DRIVE_SPEED)
        time.sleep(1)
        while globals['heading'] > lastHeading + 15 or globals['heading'] < lastHeading - 15:
            print("heading: " + str(globals['heading']))
            if globals['state1'] == 'shutdown':
                drive.rapidStop()
                break
            if globals['forwardClearance'] < STOP_DISTANCE:
                print("-------------no good, collision still there-------------")
            # not clear to turn
            elif not globals['leftTurnClear'] and globals['forwardClearance'] > STOP_DISTANCE:
                drive.straight(CAUTION_DRIVE_SPEED)
                print("turn not clear, drive straight")
            # turn
            else:
                drive.setManualSpeed(CAUTION_DRIVE_SPEED - 10, CAUTION_DRIVE_SPEED + 15)
                print("turning")
        print("------------------------------- we did it ----------------")
        # end object avoidance
        drive.straight(NORMAL_DRIVE_SPEED)
        time.sleep(10)
        globals['state1'] = 'shutdown'


    def collisionResponse():
        drive.rapidStop()
        # temp for testing
        print(debugPrefix + "[collisionResponse()]: start collision response")
        print(debugPrefix + "[collisionResponse()]: Bumper 1 status = " + str(globals['bumper1Pressed']))
        print(debugPrefix + "[collisionResponse()]: Bumper 2 status = " + str(globals['bumper2Pressed']))
        print(debugPrefix + "[collisionResponse()]: Bumper 3 status = " + str(globals['bumper3Pressed']))
        print(debugPrefix + "[collisionResponse()]: Bumper 4 status = " + str(globals['bumper4Pressed']))
        print(debugPrefix + "[collisionResponse()]: Bumper 5 status = " + str(globals['bumper5Pressed']))
        print(debugPrefix + "[collisionResponse()]: Bumper 6 status = " + str(globals['bumper6Pressed']))
        print(debugPrefix + "[collisionResponse()]: Bumper 7 status = " + str(globals['bumper7Pressed']))
        time.sleep(2)
        globals['state1'] = 'shutdown'

    

    testNum = globals['testNum']
    
    # load test flags
    import mcs.testFlags as tFlags
    if testNum > 0:
        testFile = "test.routines.test" + str(testNum) + ".testFlags"
        tFlags = importlib.import_module(testFile)

    debug = tFlags.DriveSysControl_debug
    enabled = tFlags.DriveSysControl_enabled
    debugPrefix = "[DriveSysCont]"
    if tFlags.DriveSysControl_over:
        debugPrefix += "[O]"
    if enabled:
        debugPrefix += "[E]"
    else:
        debugPrefix += "[D]"
    if debug:
        print(debugPrefix + ": process spawned")
        print(debugPrefix + ": process id = " + str(os.getpid()))

    # load drive control module
    if tFlags.DriveControl_over:
        testDir = "test.routines.test" + str(testNum) + ".DriveControl"
        DriveControl = importlib.import_module(testDir)
    else:
        import mcs.controllers.DriveControl as DriveControl
    # start drive control thread
    if enabled:
        drive = DriveControl.DriveControl()

    # load remote control module
    if tFlags.RemoteControl_over:
        testDir = "test.routines.test" + str(testNum) + ".RemoteControl"
        RemoteControl = importlib.import_module(testDir)
    else:
        import mcs.controllers.RemoteControl as RemoteControl
    # start remote control thread
    if enabled:
        thread_remoteControl = threading.Thread(target = RemoteControl.run, args = (globals, ))
        thread_remoteControl.start()

    # wait for remote controller to start routine
    # if disabled, program will wait 3 seconds then start
    while globals['state2'] == 'waitForRemote':
        if globals['state1'] == 'manual' or globals['state1'] == 'shutdown':
            break
        time.sleep(1)

    if globals['state1'] == 'straight':
        print("Test 6: Obstacle Avoidance")
        time.sleep(3)
        drive.enable()
        drive.straight(NORMAL_DRIVE_SPEED)
        compassDrive = False

    if globals['state1'] == 'compass':
        print("compass driving")
        time.sleep(3)
        drive.enable()
        drive.straight(NORMAL_DRIVE_SPEED)
        compassDrive = True

    # main loop, run until program shutdown
    while globals['state1'] != 'shutdown':
        state1 = globals['state1']
        heading = globals['heading']
        destinationHeading = globals['destinationHeading']

        # check if manual mode engaged
        if state1 == 'manual':
            drive.enable()
            while globals['state1'] == 'manual':
                drive.setManualSpeed(globals['leftSpeed'], globals['rightSpeed'])

        # check for objects in path (1 meter)
        forwardClearance = globals['forwardClearance']
        if forwardClearance < OBJECT_AVOIDANCE_STOP_DISTANCE and forwardClearance != -1:
            print("state change, object avoidance--------------")
            globals['state1'] = 'objectAvoidance'
        if forwardClearance > 100:
            drive.straight(NORMAL_DRIVE_SPEED)
        else:
            drive.straight(slowDownSpeed(forwardClearance))

        if globals['state1'] == 'objectAvoidance':
            avoidObject()

        # object avoidance clearance debug
        #print("left clearance: " + str(globals['leftTurnClear']))

        if globals['atDestination']:
            # wait until new destination heading updates
            while globals['destinationHeading'] == destinationHeading:
                drive.stop()
            drive.enable()
            # determine pivot angle and direction
            degreesOff, direction = degrOff(destinationHeading, heading)
            if direction == 'left':
                drive.pivotLeftDegrees(degreesOff)
            else:
                drive.pivotRightDegrees(degreesOff)
            globals['atDestination'] = False
            drive.straight(NORMAL_DRIVE_SPEED)
            time.sleep(3)

        # drive based on compass heading
        if compassDrive:
            #print(str(heading))
            degreesOff, adjustHeading = degrOff(destinationHeading, heading)
            # on course
            #print("heading: " + str(heading) + " destination: " + str(destinationHeading))
            if degreesOff <= DEGREES_OFF_COURSE:
                drive.straight(NORMAL_DRIVE_SPEED)
                print("straight")
            elif degreesOff > DEGREES_OFF_COURSE and adjustHeading == 'left':
                print("steer left")
                drive.veerLeftDegrees(degreesOff)
            elif degreesOff > DEGREES_OFF_COURSE and adjustHeading == 'right':
                print("steer right")
                drive.veerRightDegrees(degreesOff)
            else:
                print("Error. Heading: ", heading)
        
        # check if collision has occured
        if globals['state1'] == 'collision':
            collisionResponse()
        
    globals['bladesOn'] = False
    drive.stop()   
    drive.disable()

    if debug:
        print(debugPrefix + ": end of program")
