# standard libraries
import importlib
import threading
import multiprocessing as multiproc
from dataclasses import dataclass
import math
import time
from geopy.distance import great_circle
from vincenty import vincenty

import mcs.pinAssignments as pins

ratio = 85 / 100
DISTANCE_THRESHOLD = 1.5

@dataclass
class waypoint:
    lon: float
    lat: float

# get destination heading from current and destination gps
def getDestinationHeading(currentLon, currentLat, destinationLon, destinationLat):
    # get heading in radians
    heading = math.atan2(destinationLat - currentLat, ratio * (destinationLon - currentLon))
    # convert to degreees and adjust for compass orienation
    heading = 90 - math.degrees(heading)
    # fix if less than zero
    if heading < 0:
        heading += 360
    return heading

# determine if arrived at destination from current and destination position
def arrivedAtDestination(currentLon, currentLat, destinationLon, destinationLat):
    p1 = (currentLat, currentLon)
    p2 = (destinationLat, destinationLon)
    distance = great_circle(p1, p2).meters
    #print(distance)
    #print("distance to destination: " + str(distance))
    # arrived at destination
    if distance < DISTANCE_THRESHOLD:
        return True
    else:
        return False

## This class is the high level controller for the blade motors
# Provides high level control by integrating MD30C and relay control
# @author Keith
# @note 12/16/2020: Added commenting to code. -KS
def run(globals):

    # load test flags
    import mcs.testFlags as tFlags
    if tFlags.testNum > 0:
        testFile = "test.routines.test" + str(tFlags.testNum) + ".testFlags"
        tFlags = importlib.import_module(testFile)

    ## Boolean indicating if debug info should be included for this module
    debug = tFlags.Navigation_debug
    ## Boolean to indicate if blade motors should be used. 
    enabled = tFlags.Navigation_enabled
    ## String used for debugging
    debugPrefix = "[Navigation]"
    if enabled:
        debugPrefix += "[E]: "
    else:
        debugPrefix += "[D]: "  
    if debug:
        print(debugPrefix + "init blade controller")

        
    if enabled:
        # load GPS module
        if tFlags.NEO_M8P_over:
            testDir = "test.routines.test" + str(testNum) + ".NEO_M8P"
            NEO_M8P = importlib.import_module(testDir)
        else:
            import mcs.firmware.NEO_M8P as NEO_M8P
        # start GPS thread
        thread_gps = threading.Thread(target = NEO_M8P.run, args = (True, tFlags.NEO_M8P_enabled, tFlags.NEO_M8P_RTK_enabled, tFlags.NEO_M8P_over, pins.rtkStatus, globals))
        thread_gps.start()

    # main loop, run until end of program
    if enabled:
        
        # go to waypoint A
        A = waypoint(-80.709624699, 35.237648)
        destinationLon = A.lon
        destinationLat = A.lat

        newDestinationHeading = -1
        prevDestinationHeading = -1

        while globals['state1'] != 'shutdown':
            time.sleep(1)
            startx = globals['startLon']
            starty = globals['startLat']
            #print("start x and y = " + str(x) + " " + str(y))
            currentLon = globals['lon']
            currentLat = globals['lat']
            # make sure gps readings are good
            if currentLon != -1 and currentLat != -1:
                # get destination heading from current and destination position
                newDestinationHeading = getDestinationHeading(currentLon, currentLat, destinationLon, destinationLat)
                # update globals if new value
                if newDestinationHeading != prevDestinationHeading:
                    globals['destinationHeading'] = newDestinationHeading
                #if debug:
                #    print(debugPrefix + ": destination heading = " + str(newDestinationHeading))
                # arrived at destination
                #if False:
                if arrivedAtDestination(currentLon, currentLat, destinationLon, destinationLat):
                    print(debugPrefix + ": destination reached")
                    if globals['state1'] == 'returnToStart':
                        print("Arrived at start position")
                        globals['state1'] = 'shutdown'
                        break
                    else:
                        print("Arrived at first point")
                        globals['state1'] = 'returnToStart'
                        globals['state2'] = 'init'
                        destinationLat = globals['startLat']
                        destinationLon = globals['startLon']
                    globals['atDestination'] = True
    # wait for threads to end
    if enabled:
        thread_gps.join()

    print(debugPrefix + "end of module")