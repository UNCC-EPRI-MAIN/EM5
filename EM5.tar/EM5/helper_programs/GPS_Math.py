# GPS_math.py
#
# This program was used for testing basic math related to GPS
#   localization. In particular, finding the compass heading
#   and distance between two GPS points
#
# Compass Heading
#   Uses basic trig to calculate angle between two points
#
# Distance
#   Uses great circle method which is implemented by a library.
#
# A Note About Accuracy/Precision
#   Unfortunately we don't have the proper tools or know of proper
#   methods to properly bench mark these calculations. For example,
#   we can compare the distance calculations on two known points
#   but if we're off by 1 meter its impossible to be sure if the
#   GPS readings are off or the method of calculating distance.
#   Although we weren't able to quantify our error we found it to
#   reasonable for our application.

import math
from geopy.distance import great_circle


AX = -80.7096746
AY = 35.2376407
BX = -80.7096318999
BY = 35.2376935
CY = 35.2376129999
CX = -80.7096234999
DX = -80.7095595
DY = 35.2375543
PX = -80.7096712
PY = 35.2376673

dlon = BX - AX
y = math.sin(dlon) * math.cos(BY)
x = math.cos(AY)*math.sin(BY) - math.sin(AY)*math.cos(BY)*math.cos(dlon)

# Note: 1 degree lat is not equal to 1 degree lon
#   ratio is the ratio between a lat and a lon
ratio = 85 / 100

#AX = ratio * AX
#BX = ratio * BX
#CX = ratio * CX
#DX = ratio * DX

# get heading from basic trig
heading = math.atan2(BY - CY, ratio * (BX - CX))
# convert to degrees and adjust for compass headings
heading = 90 - math.degrees(heading)

# fix heading if negative
if heading < 0:
    heading += 360

# display result
print(str(heading))

# library used for distance calcs needs data in point format
# note lat comes before lon
p1 = (AY, AX)
p2 = (PY, PX)

# calcualte and display distance
distance = great_circle(p1, p2).meters
print(str(distance))
