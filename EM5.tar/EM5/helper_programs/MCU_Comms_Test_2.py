# MCU_Comms_Test
#
# This program was meant to test communications form the
#   Raspberry Pi to the MCU. The communications utilizes
#   SPI which is routed through the PCB. Unfortunately
#   there was an unresolved issue and communication
#   is not fully up and running. We were able to transmit
#   a single byte successfully but when sending multiple 
#   bytes we got corrupt data. The cause of the problem is
#   unknown. If there is an issue related to the PCB, I2C
#   could be utilized by connecting pins on the PCB with 
#   simple dupont wires.

import spidev

spi_bus = 0
spi_device = 0
spi = spidev.SpiDev()
spi.open(spi_bus, spi_device)
spi.max_speed_hz = 1000000

def getByte(position):
    rcv_byte = spi.xfer2([0x80])
    rcv_byte = spi.xfer2([0x80])
    data_recv = rcv_byte[0]
    print(str(data_recv))
    return data_recv
    #if (data_recv != 0x80):
    #    print ("Unable to communicate with Arduino "+str(data_recv))
    #    quit()

val0 = getByte(0x00)
#val1 = getByte(0x01)
#val2 = getByte(0x02)
#val3 = getByte(0x03)
#vals = bytes([val0, val1, val2, val3])
#total = int.from_bytes(vals, byteorder='big', signed=True)
#print(total)

