# MCU_Comms_Test
#
# This program was meant to test communications form the
#   Raspberry Pi to the MCU. The communications utilizes
#   SPI which is routed through the PCB. Unfortunately
#   there was an unresolved issue and communication
#   is not fully up and running. We were able to transmit
#   a single byte successfully but when sending multiple 
#   bytes we got corrupt data. The cause of the problem is
#   unknown. If there is an issue related to the PCB, I2C
#   could be utilized by connecting pins on the PCB with 
#   simple dupont wires.

import time
import spidev

spi_bus = 0
spi_device = 0
spi = spidev.SpiDev()
spi.open(spi_bus, spi_device)
spi.max_speed_hz = 1000000

steps = -1
elapsedTime = -1
totalCoulombs = -1
maxCurrent = -1
totalReads = -1

send_byte = 0
rcv_byte = spi.xfer2([send_byte])
print(rcv_byte)
rcv_byte = spi.xfer2([send_byte])
data_recv0 = rcv_byte[0]
print(rcv_byte)
print(str(data_recv0))
send_byte = 1
rcv_byte = spi.xfer2([send_byte])
print(rcv_byte)
rcv_byte = spi.xfer2([send_byte])
print(rcv_byte)
data_recv1 = rcv_byte[0]
print(str(data_recv1))
send_byte = 2
rcv_byte = spi.xfer2([send_byte])
print(rcv_byte)
rcv_byte = spi.xfer2([send_byte])
print(rcv_byte)
data_recv2 = rcv_byte[0]
print(str(data_recv2))
send_byte = 3
rcv_byte = spi.xfer2([send_byte])
print(rcv_byte)
print(rcv_byte)
rcv_byte = spi.xfer2([send_byte])
print(rcv_byte)
print(rcv_byte)
data_recv3 = rcv_byte[0]
print(str(data_recv3))
byteList = [data_recv0, data_recv1, data_recv2, data_recv3]
arr = bytearray(byteList)
steps = int.from_bytes(arr, byteorder='big', signed=True)
print(steps)