# MCU Discharge Test
#
# This program is meant to receive data from the MCU
#   and store it csv files for later anlaysis. To prevent
#   data loss when the battery dies, new csv files are
#   created and saved on a set interval.

import time
import spidev

spi_bus = 0
spi_device = 0
spi = spidev.SpiDev()
spi.open(spi_bus, spi_device)
spi.max_speed_hz = 1000000

steps = -1
elapsedTime = -1
totalCoulombs = -1
maxCurrent = -1
totalReads = -1

FILE_INTERVAL_THRESHOLD_SECS = 10
## 15 min intervals
READ_INTERVAL_SEC = 5

fileNumber = 1

testComplete = False
startTime = time.time()
lastTime = startTime

while not testComplete:

    # check if test should be over
    if fileNumber > 2:
        testComplete = True

    # create new csv file
    file = open("DischargeTest_" + str(fileNumber) + ".csv","w")
    # add column headers
    line = "Elapsed Time from Pi (sec), Steps from ADC, Elapsed Time from MCU (msec), Total Coulombs (mC), Mac Current (mA), Total Reads\n"
    file.writelines(line)

    startNewFile = False
    while not startNewFile:

        startNewFile = False

        # delay reads
        time.sleep(READ_INTERVAL_SEC)

        send_byte = 0
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv0 = rcv_byte[0]
        send_byte = 1
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv1 = rcv_byte[0]
        send_byte = 2
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv2 = rcv_byte[0]
        send_byte = 3
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv3 = rcv_byte[0]
        byteList = [data_recv0, data_recv1, data_recv2, data_recv3]
        arr = bytearray(byteList)
        steps = int.from_bytes(arr, byteorder='big', signed=True)
        #print(steps)

        # time elapsed milis
        send_byte = 4
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv0 = rcv_byte[0]
        send_byte = 5
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv1 = rcv_byte[0]
        send_byte = 6
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv2 = rcv_byte[0]
        send_byte = 7
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv3 = rcv_byte[0]
        byteList = [data_recv0, data_recv1, data_recv2, data_recv3]
        arr = bytearray(byteList)
        elapsedTime = int.from_bytes(arr, byteorder='big', signed=True)
        #print(steps)

        # total coulombs
        send_byte = 8
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv0 = rcv_byte[0]
        send_byte = 9
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv1 = rcv_byte[0]
        send_byte = 10
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv2 = rcv_byte[0]
        send_byte = 11
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv3 = rcv_byte[0]
        byteList = [data_recv0, data_recv1, data_recv2, data_recv3]
        arr = bytearray(byteList)
        totalCoulombs = int.from_bytes(arr, byteorder='big', signed=True)
        #print(totalCoulombs)

        # max current
        send_byte = 12
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv0 = rcv_byte[0]
        send_byte = 13
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv1 = rcv_byte[0]
        send_byte = 14
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv2 = rcv_byte[0]
        send_byte = 15
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv3 = rcv_byte[0]
        byteList = [data_recv0, data_recv1, data_recv2, data_recv3]
        arr = bytearray(byteList)
        maxCurrent = int.from_bytes(arr, byteorder='big', signed=True)
        #print(maxCurrent)

        # total reads
        send_byte = 16
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv0 = rcv_byte[0]
        send_byte = 17
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv1 = rcv_byte[0]
        send_byte = 18
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv2 = rcv_byte[0]
        send_byte = 19
        rcv_byte = spi.xfer2([send_byte])
        rcv_byte = spi.xfer2([send_byte])
        data_recv3 = rcv_byte[0]
        byteList = [data_recv0, data_recv1, data_recv2, data_recv3]
        arr = bytearray(byteList)
        totalReads = int.from_bytes(arr, byteorder='big', signed=True)
        #print(totalReads)

        # write data
        # add time stamp
        line = str(time.time() - startTime) + ","
        # add steps
        line += str(steps) + ","
        # add elapsed time
        line += str(elapsedTime) + ","
        # add total coulombs
        line += str(totalCoulombs) + ","
        # add max current
        line += str(maxCurrent) + ","
        # add total reads
        line += str(totalReads) + "\n"
        file.writelines(line)

        # check if time interval is over
        currentTime = time.time()
        if currentTime - lastTime > FILE_INTERVAL_THRESHOLD_SECS:
            file.close() #to change file access modes
            lastTime = currentTime
            startNewFile = True
            print("File Number: " + str(fileNumber))
            fileNumber += 1

