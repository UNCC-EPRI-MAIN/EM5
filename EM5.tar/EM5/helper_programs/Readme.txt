This section contains small fragments of code or programs that may be useful for various purposes.
Note: None of these programs are part of the main system (MCS)